# Correction log

Append-only. Newest first. Every verified error is fixed on the site and recorded here with the old value intact.

Statuses: **submitted** → **under review** → **verified** (fixed) or **rejected** (with reason).

Send one: ryan@wilde.energy

---

## 2026-09-07 — Apple 20× cap stated imprecisely
**Status: verified — fixed.** The site described a 20× cap on Apple's chief-executive pay as "about $3 million." The exact figure is 20 × $139,483 = **$2,789,660**. The rounding overstated the modeled cap by about $210,000. All model figures are now computed from the data and shown with their arithmetic. Found in internal review.

## 2026-09-07 — Starbucks listed in sources before it was in the data
**Status: verified — fixed.** An earlier version of the homepage footer credited a Starbucks filing while Starbucks was not yet on the ledger. The company has since been added with its filing; the footer no longer lists companies individually.

## 2026-09-07 — Costco ratio is fiscal 2024, not fiscal 2025
**Status: disclosed, not an error.** Costco's fiscal 2025 proxy figures could not be verified against a primary filing at the time of publication. The fiscal 2024 numbers ($12,229,741 and $47,092) are shown with their year stated. This entry exists so the gap is on the record rather than glossed.

---

*No externally submitted corrections yet. The first one gets logged here with credit.*
