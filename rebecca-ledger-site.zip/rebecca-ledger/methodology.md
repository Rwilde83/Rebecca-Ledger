# Methodology

Updated 2026-09-07. This document is the contract. If the site ever contradicts it, the site is wrong.

## Data status labels

Every figure carries one:

- **verified** — copied from a primary source: a company's own SEC filing (DEF 14A proxy statement, 10-K, or equivalent). The form type, filing date, and link are on the company page.
- **calculated** — arithmetic performed by the Ledger on verified figures. The calculation is always shown.
- **estimate** — a reasoned figure from incomplete information. Labeled as such, with the reasoning.
- **proposal** — a Rebecca Ledger model. Never a prediction, never a company statistic, never a claim about what a company will or should do without saying so plainly.
- **insufficient data** — we don't have it. Shown as a blank, never filled with a guess.

## Where the pay figures come from

US public companies have been required since 2018 (Dodd-Frank §953(b), Reg S-K Item 402(u)) to disclose, once a year, their chief executive's total compensation, their median employee's total compensation, and the ratio. Both numbers use the Summary Compensation Table definition, which includes salary, bonus, stock and option awards at grant-date value, and other compensation.

The Ledger copies those two numbers and the stated ratio. Where a filing states the ratio, we mark it verified and use theirs. Where we hold the two figures but not a stated ratio, we divide and mark it calculated, showing the arithmetic.

## The comparability caveat, stated plainly

SEC rules let each company choose how it identifies its median employee. Companies may or may not annualize part-time and partial-year pay, may exclude some foreign employees under a de minimis rule, and pick their own determination date. **Ratios are exact within a company and approximate between companies.**

This matters most at the extremes. Genesco's $3,867 median and Starbucks' $17,279 median are both real, disclosed, part-time-heavy figures that were not annualized. They are not full-time wages, and the site says so on those pages. Comparing them to a company with few part-time roles overstates the difference in how the two treat a full-time worker.

The historical series (Economic Policy Institute) uses a different method again — the 350 largest firms measured against a full-time production worker in the same industry — so the honest comparison for any modern company disclosure is against the AFL-CIO's S&P 500 average of 312 to 1 for 2025, not against the 1965 figure of about 20 to 1.

## The Pay Fairness score

One number, measuring one thing: the ratio. It is not a judgment of a company overall, and it is deliberately the only score published, because it is the only one we have data for.

    score = 100 × (1 − (ln(ratio) − ln(20)) ÷ (ln(1000) − ln(20)))
    clamped to 0–100, rounded

A ratio of 20:1 scores 100. A ratio of 1000:1 or worse scores 0. The scale is logarithmic because the difference between 20:1 and 100:1 is a bigger change in kind than the difference between 900:1 and 980:1.

The choice of 20 as the top anchor is a value judgment, not a finding. It comes from the mid-century US ratio and from the range used in codetermination-style proposals. **Disagree with the anchor and the whole score moves.** That's a fair criticism and worth sending in.

Current scores:

| Company | Ratio | Pay Fairness |
|---|---|---|
| Starbucks | 1,794:1 | 0 |
| Genesco | 1,149:1 | 0 |
| Walmart | 958:1 | 1 |
| Nike | 746:1 | 7 |
| Apple | 533:1 | 16 |
| Coty | 412:1 | 23 |
| Cloudflare | 387:1 | 24 |
| Medtronic | 303:1 | 31 |
| Salesforce | 296:1 | 31 |
| Constellation Brands | 293:1 | 31 |
| Costco | 262:1 | 34 |
| Electronic Arts | 260:1 | 34 |
| Public Storage | 255:1 | 35 |
| News Corp | 221:1 | 39 |
| Lovesac | 218:1 | 39 |
| PSEG | 79:1 | 65 |
| Everest Group | 49:1 | 77 |
| Cantaloupe | 12:1 | 100 |

Every other proposed category — employee ownership, transparency, profit sharing, executive concentration, worker voice — shows **insufficient data**. There is no composite "Rebecca Score" because inventing one from a single input would be dressing one number up as six.

## The 20× model

For each company: `cap = 20 × that company's own median employee pay`, `difference = current CEO pay − cap`, `median salaries equivalent = difference ÷ median pay`.

It changes exactly one variable and holds everything else still. It assumes nothing about taxes, share price, hiring, retention, or whether a company would ever do it. It exists to make a large number legible, and it is labeled a proposal everywhere it appears.

Worked example, Apple: 20 × $139,483 = $2,789,660. Against $74,294,811 in disclosed fiscal 2025 compensation, the difference is $71,505,151 — about 513 more employees at Apple's own median pay. An earlier version of this site rounded that cap to "$3 million"; the exact figure is $2,789,660 and the site now shows the arithmetic.

## Global estimates

The figure of roughly $150–200 billion a year for worldwide top-executive pay is an **estimate** by the author, extrapolated from disclosed proxy data across large public companies. It is not sourced to a published study and is labeled an estimate wherever it appears. If you have a better number, send it.

## Corrections

Errors are fixed and logged in `corrections.md`, dated, with the old value preserved. Nothing is quietly edited. A correction submitted and verified is a contribution, not an embarrassment.

## What this site does not claim

- That unequal pay is illegal, or that any company here has done anything wrong. Every figure is a lawful, voluntary disclosure.
- That a high ratio proves bad management, or a low one proves good management.
- That the AI experiment described on the site has been run. It has not.
- That the author is neutral about the subject. He isn't, and the proposals are labeled proposals so you can take the data and reject the argument.
