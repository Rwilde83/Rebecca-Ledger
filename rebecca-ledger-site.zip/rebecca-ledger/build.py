#!/usr/bin/env python3
"""Rebecca Ledger build script.

Reads ledger.json (the single source of truth) and generates:
  /company/<slug>/index.html   one static, indexable page per company
  /company/index.html          the full list
  /ledger.csv                  open data
  /sitemap.xml

Run:  python3 build.py
Adding a company means editing ledger.json and re-running this.
"""
import json, os, html, math

SITE = "https://rebecca.wilde.energy"
D = json.load(open("ledger.json"))
COS = D["companies"]
BENCH = D["benchmark"]["sp500Average2025"]

HEAD = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<meta property="og:title" content="{ogt}">
<meta property="og:description" content="{desc}">
<meta property="og:url" content="{url}">
<link rel="canonical" href="{url}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300..800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{root}style.css">
{extra}</head>
<body>
<header><div class="wrap">
<a class="brand" href="{root}">The Rebecca Ledger</a>
<nav aria-label="Sections">
<a href="{root}company/">Companies</a>
<a href="{root}#watchers">Three Watchers</a>
<a href="{root}methodology.md">Methodology</a>
<a href="{root}act.html">Act</a>
</nav></div></header>
"""

FOOT = """<footer><div class="wrap">
<p><strong>Sources.</strong> Every company figure on this site comes from that company's own filing with the U.S. Securities and Exchange Commission. Each number carries a status: <span class="tag verified">verified</span> from a primary filing, <span class="tag calculated">calculated</span> by arithmetic on verified figures, <span class="tag estimate">estimate</span>, or <span class="tag proposal">proposal</span> — a Rebecca Ledger model, never a prediction and never presented as a company statistic.</p>
<p>Benchmark: the AFL-CIO puts the 2025 average S&amp;P 500 ratio at {b} to 1. Historical ratios: Economic Policy Institute; mid-century levels also documented by Frydman and Saks.</p>
<p>Built and maintained by <a href="https://wilde.energy">Ryan Wilde</a> in Lake Stevens, Washington — one person with a laptop, not an institution. Data and code free to copy, check, and improve. Found an error? <a href="{root}#wrong">Prove us wrong</a>.</p>
</div></footer>
</body>
</html>
"""

def money(n):
    if n >= 1_000_000: 
        v = n/1_000_000
        return "$%s million" % (("%.1f" % v).rstrip("0").rstrip("."))
    return "$%s" % f"{n:,}"

def page(c):
    r, ceo, med, m20 = c["ratio"], c["ceo"], c["median"], c["model20"]
    url = f"{SITE}/company/{c['slug']}/"
    desc = (f"{c['name']}: median employee {money(med['pay'])}, chief executive {money(ceo['pay'])}. "
            f"{r:,} to 1, from the company's own {c['source']['form']} filing for fiscal {c['fiscalYear']}.")
    src = c["source"]
    srclabel = "the filing" if src["exact"] else "this company's SEC filing list"
    vs = "above" if r > BENCH else "below"
    ratio_tag = c["ratioStatus"]
    ratio_expl = ("This ratio is disclosed by the company itself in the filing."
                  if ratio_tag == "verified" else
                  "The company did not state a ratio in the source we hold, so the Ledger divided the two verified figures.")
    ownership_note = ("No company on the ledger yet publishes what share of its stock is held by "
                      "rank-and-file employees. That silence is itself the finding.")
    bars = f"""<div class="ledger" role="img" aria-label="{html.escape(c['name'])}: median employee {money(med['pay'])}, chief executive {money(ceo['pay'])}, drawn to scale.">
<div class="row"><div class="who">Median employee<small>{html.escape(med['note'])}</small></div><div class="track"><div class="bar" style="width:{max(med['pay']/ceo['pay']*100,0.06):.3f}%"></div><span class="val" style="left:calc({max(med['pay']/ceo['pay']*100,0.06):.3f}% + .5rem)">${med['pay']:,}</span></div></div>
<div class="row"><div class="who">A 20 to 1 cap<small>Rebecca Ledger model</small></div><div class="track"><div class="bar" style="width:{max(m20['cap']/ceo['pay']*100,0.06):.3f}%;background:var(--cobalt)"></div><span class="val" style="left:calc({max(m20['cap']/ceo['pay']*100,0.06):.3f}% + .5rem)">${m20['cap']:,}</span></div></div>
<div class="row top"><div class="who">{html.escape(ceo['name'])}<small>chief executive, fiscal {c['fiscalYear']}</small></div><div class="track"><div class="bar" style="width:100%"></div><span class="val">${ceo['pay']:,}</span></div></div>
</div>"""

    note = f'<p class="prose">{html.escape(c["note"])}</p>' if c["note"] else ""

    extra = ('<script type="application/ld+json">' + json.dumps({
        "@context":"https://schema.org","@type":"Dataset",
        "name":f"{c['name']} executive-to-median pay ratio, fiscal {c['fiscalYear']}",
        "description":desc,"url":url,"license":"https://creativecommons.org/licenses/by/4.0/",
        "creator":{"@type":"Person","name":"Ryan Wilde"},
        "isBasedOn":src["url"],"dateModified":D["updated"]
    }) + "</script>\n")

    body = f"""
<main>
<section style="border-top:0;padding-top:1.5rem">
<div class="wrap">
<p class="kicker"><a href="../">All companies</a> · {html.escape(c['country'])} · fiscal {c['fiscalYear']}</p>
<h1>{html.escape(c['name'])}</h1>
<p class="hero-num">{r:,}<small>times · chief executive pay ÷ median employee pay <span class="tag {ratio_tag}">{ratio_tag}</span></small></p>
<p class="prose">It would take {html.escape(c['name'])}'s median employee <strong>{r:,} years</strong> to earn what its chief executive earned in one. That is {vs} the {BENCH} to 1 average across the S&amp;P 500 in 2025.</p>
{bars}
{note}
<details><summary>Show the evidence</summary>
<div class="evidence"><dl>
<dt>Source</dt><dd>{html.escape(c['name'])}, SEC Form {html.escape(src['form'])}, filed {html.escape(src['filed'])} — <a href="{html.escape(src['url'])}" target="_blank" rel="noopener">open {srclabel}</a></dd>
<dt>Chief executive total compensation <span class="tag verified">verified</span></dt><dd>${ceo['pay']:,} — {html.escape(ceo['name'])}, as reported in the Summary Compensation Table</dd>
<dt>Median employee total compensation <span class="tag verified">verified</span></dt><dd>${med['pay']:,} — {html.escape(med['note'])}</dd>
<dt>Ratio <span class="tag {ratio_tag}">{ratio_tag}</span></dt><dd>{html.escape(c['ratioCalc'])}. {ratio_expl}</dd>
<dt>Retrieved</dt><dd>{html.escape(src['retrieved'])}</dd>
<dt>Methodology caution</dt><dd>SEC rules let each company choose how it identifies its median employee — whether part-time and seasonal pay is annualized, which countries are included. Ratios are exact within a company and approximate between companies. <a href="../../methodology.md">Full methodology</a>.</dd>
</dl></div></details>
</div>
</section>

<section>
<div class="wrap">
<h2>The numbers</h2>
<div class="metrics">
<div class="metric"><div class="v">${ceo['pay']:,}</div><div class="k">Chief executive <span class="tag verified">verified</span></div><div class="n">{html.escape(ceo['name'])}, fiscal {c['fiscalYear']} total compensation</div></div>
<div class="metric"><div class="v">${med['pay']:,}</div><div class="k">Median employee <span class="tag verified">verified</span></div><div class="n">{html.escape(med['note'])}</div></div>
<div class="metric"><div class="v">{r:,}:1</div><div class="k">Ratio <span class="tag {ratio_tag}">{ratio_tag}</span></div><div class="n">S&amp;P 500 average is {BENCH}:1</div></div>
<div class="metric"><div class="v">{c['payFairness']}</div><div class="k">Pay Fairness score <span class="tag calculated">calculated</span></div><div class="n">0–100, from the ratio alone. <a href="../../methodology.md">Formula</a></div></div>
<div class="metric dim"><div class="v" style="color:var(--mute)">—</div><div class="k">Employee ownership <span class="tag insufficient">insufficient data</span></div><div class="n">Not disclosed. {ownership_note}</div></div>
<div class="metric dim"><div class="v" style="color:var(--mute)">—</div><div class="k">Buybacks &amp; net income <span class="tag insufficient">insufficient data</span></div><div class="n">Not yet collected for this company. Want to add it? <a href="../../#challenge">Take the Rebecca Challenge</a>.</div></div>
</div>

<h2 style="margin-top:2.5rem">What 20 to 1 would look like <span class="tag proposal">proposal</span></h2>
<p class="prose">This is a Rebecca Ledger model, not a prediction and not something the company has said or done. It caps chief-executive pay at twenty times this company's own median employee, and changes nothing else.</p>
<table>
<tr><th>Chief executive today <span class="tag verified">verified</span></th><td>${ceo['pay']:,}</td></tr>
<tr><th>Under a 20× cap <span class="tag proposal">proposal</span></th><td>${m20['cap']:,} <span class="mute">(20 × ${med['pay']:,})</span></td></tr>
<tr><th>Difference <span class="tag calculated">calculated</span></th><td>${m20['freed']:,}</td></tr>
<tr><th>What the difference equals <span class="tag calculated">calculated</span></th><td>about {m20['medianSalaries']:,} more employees paid at this company's own median</td></tr>
</table>
<p class="caption">The arithmetic is the whole model: one year of the difference, divided by one median salary. It assumes nothing about taxes, share price, or whether the company would do it. It is meant to make a large number legible, not to predict a decision.</p>

<p style="margin-top:2rem">
<button class="btn" id="card">Download share card</button>
<button class="btn secondary" id="cite">Copy citation</button><span id="ok" class="ok" hidden>Copied</span>
<a class="btn secondary" href="../../act.html">Write to someone about it</a>
</p>
<p class="small mute">Wrong about any of this? <a href="mailto:ryan@wilde.energy?subject=Correction%3A%20{html.escape(c['name'])}&body=What%20I%20think%20is%20wrong%3A%0A%0AMy%20source%3A%0A%0A">Send a correction</a> — corrections are published, dated, and never quietly edited.</p>
<canvas id="cv" width="1200" height="675" style="display:none"></canvas>
</div>
</section>
</main>
<script>
const C={json.dumps({"name":c["name"],"ratio":r,"ceo":ceo["pay"],"med":med["pay"],"fy":c["fiscalYear"],"form":src["form"],"filed":src["filed"],"url":src["url"],"slug":c["slug"]})};
document.getElementById('cite').addEventListener('click',async()=>{{
  const t=`${{C.name}}, fiscal ${{C.fy}}: median employee $${{C.med.toLocaleString()}}, chief executive $${{C.ceo.toLocaleString()}}, a ratio of ${{C.ratio.toLocaleString()}} to 1. Source: ${{C.name}} SEC Form ${{C.form}}, filed ${{C.filed}}. Via The Rebecca Ledger, {SITE}/company/${{C.slug}}/ (retrieved ${{new Date().toISOString().slice(0,10)}}).`;
  try{{await navigator.clipboard.writeText(t);const o=document.getElementById('ok');o.hidden=false;setTimeout(()=>o.hidden=true,2000);}}catch(e){{}}
}});
document.getElementById('card').addEventListener('click',()=>{{
  const cv=document.getElementById('cv'),x=cv.getContext('2d'),W=1200,H=675;
  x.fillStyle='#1C2430';x.fillRect(0,0,W,H);
  x.fillStyle='#F5C518';x.font='800 190px "Bricolage Grotesque",system-ui,sans-serif';
  x.fillText(C.ratio.toLocaleString()+':1',70,250);
  x.fillStyle='#F2F4F5';x.font='600 44px "Bricolage Grotesque",system-ui,sans-serif';
  x.fillText(C.name,70,330);
  x.font='400 32px "Bricolage Grotesque",system-ui,sans-serif';
  x.fillText('Median employee  $'+C.med.toLocaleString(),70,410);
  x.fillText('Chief executive   $'+C.ceo.toLocaleString(),70,458);
  x.fillStyle='#6E7882';x.font='400 24px "Bricolage Grotesque",system-ui,sans-serif';
  x.fillText(C.name+' SEC Form '+C.form+', filed '+C.filed+'. Fiscal '+C.fy+'. Their own numbers.',70,545);
  x.fillStyle='#F2F4F5';x.font='600 26px "Bricolage Grotesque",system-ui,sans-serif';
  x.fillText('The Rebecca Ledger  ·  rebecca.wilde.energy',70,600);
  const a=document.createElement('a');a.download='rebecca-ledger-'+C.slug+'.png';a.href=cv.toDataURL('image/png');a.click();
}});
</script>
"""
    head = HEAD.format(title=f"{c['name']} — {r:,} to 1 — The Rebecca Ledger",
                       desc=html.escape(desc), ogt=f"{c['name']}: {r:,} to 1",
                       url=url, root="../../", extra=extra)
    return head + body + FOOT.format(b=BENCH, root="../../")


def index_page():
    rows = "\n".join(
        f'<a class="co{" low" if c["ratio"]<100 else ""}" href="{c["slug"]}/"><div class="r">{c["ratio"]:,}<small>to 1</small></div>'
        f'<div class="n">{html.escape(c["name"])}</div>'
        f'<div class="d">${c["median"]["pay"]:,} vs ${c["ceo"]["pay"]:,} · FY{c["fiscalYear"]}</div></a>'
        for c in COS)
    body = f"""
<main><section style="border-top:0"><div class="wrap">
<p class="kicker">{len(COS)} companies · updated {D['updated']}</p>
<h1>Every company on the ledger</h1>
<p class="lede prose">Sorted by how many years its median employee would need to work to earn what its chief executive earned in one year. Blue marks anything under 100 to 1. Every figure comes from the company's own SEC filing.</p>
<p><input id="f" placeholder="Filter companies" aria-label="Filter companies"></p>
<div class="grid" id="g">{rows}</div>
<p class="caption" style="margin-top:1.5rem">Missing a company? <a href="../#challenge">Research it and send it in</a> — or <a href="mailto:ryan@wilde.energy?subject=Company%20request">just ask for it</a>. The whole dataset is at <a href="../ledger.json">ledger.json</a> and <a href="../ledger.csv">ledger.csv</a>.</p>
</div></section></main>
<script>
document.getElementById('f').addEventListener('input',e=>{{
 const q=e.target.value.toLowerCase();
 document.querySelectorAll('#g .co').forEach(a=>{{a.style.display=a.textContent.toLowerCase().includes(q)?'':'none'}});
}});
</script>
"""
    head = HEAD.format(title=f"All {len(COS)} companies — The Rebecca Ledger",
                       desc="Executive-to-median pay ratios for every company on the Rebecca Ledger, each from the company's own SEC filing.",
                       ogt="Every company on the ledger", url=f"{SITE}/company/", root="../", extra="")
    return head + body + FOOT.format(b=BENCH, root="../")


os.makedirs("company", exist_ok=True)
for c in COS:
    os.makedirs(f"company/{c['slug']}", exist_ok=True)
    open(f"company/{c['slug']}/index.html", "w").write(page(c))
open("company/index.html", "w").write(index_page())

# open data: CSV
import csv as _csv
with open("ledger.csv", "w", newline="") as f:
    w = _csv.writer(f)
    w.writerow(["slug","company","ticker","country","fiscal_year","ceo_name","ceo_pay_usd",
                "median_pay_usd","ratio","ratio_status","pay_fairness_score",
                "cap_20x_usd","difference_usd","median_salaries_equivalent",
                "source_form","source_filed","source_url","retrieved"])
    for c in COS:
        w.writerow([c["slug"],c["name"],c["ticker"],c["country"],c["fiscalYear"],c["ceo"]["name"],
                    c["ceo"]["pay"],c["median"]["pay"],c["ratio"],c["ratioStatus"],c["payFairness"],
                    c["model20"]["cap"],c["model20"]["freed"],c["model20"]["medianSalaries"],
                    c["source"]["form"],c["source"]["filed"],c["source"]["url"],c["source"]["retrieved"]])

urls = [f"{SITE}/", f"{SITE}/company/", f"{SITE}/act.html"] + [f"{SITE}/company/{c['slug']}/" for c in COS]
open("sitemap.xml","w").write(
 '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
 + "".join(f"<url><loc>{u}</loc><lastmod>{D['updated']}</lastmod></url>\n" for u in urls) + "</urlset>\n")
open("robots.txt","w").write(f"User-agent: *\nAllow: /\nSitemap: {SITE}/sitemap.xml\n")

print(f"built {len(COS)} company pages, company/index.html, ledger.csv, sitemap.xml, robots.txt")
